"use client"

import type React from "react"

import { useRef } from "react"
import { motion, useScroll, useTransform, useInView } from "framer-motion"
import { ArrowDown, Code, BarChart3, Database, Layers, Settings, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import DashboardAnimation from "@/components/dashboard-animation"
import AnimatedBackground from "@/components/animated-background"
import { useMobile } from "@/hooks/use-mobile"

export default function Home() {
  const isMobile = useMobile()
  const heroRef = useRef<HTMLDivElement>(null)
  const servicesRef = useRef<HTMLDivElement>(null)
  const dashboardRef = useRef<HTMLDivElement>(null)
  const contactRef = useRef<HTMLDivElement>(null)

  const heroInView = useInView(heroRef, { once: false })
  const servicesInView = useInView(servicesRef, { once: false })
  const dashboardInView = useInView(dashboardRef, { once: false })
  const contactInView = useInView(contactRef, { once: false })

  const scrollToSection = (ref: React.RefObject<HTMLDivElement>) => {
    ref.current?.scrollIntoView({ behavior: "smooth" })
  }

  const { scrollY } = useScroll()
  const headerOpacity = useTransform(scrollY, [0, 100], [0, 1])

  return (
    <main className="relative min-h-screen bg-black text-white overflow-hidden">
      {/* Animated Background (now site-wide) */}
      <AnimatedBackground />

      {/* Gradient overlays for each section */}
      <div className="fixed inset-0 bg-gradient-to-b from-black/60 to-black/80 z-10 pointer-events-none" />

      {/* Sticky Header */}
      <motion.header className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md" style={{ opacity: headerOpacity }}>
        <div className="container mx-auto flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="bg-[#4285F4] rounded-md p-1.5 flex items-center justify-center w-10 h-10">
              <svg
                viewBox="0 0 24 24"
                width="24"
                height="24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="text-white"
              >
                <path
                  d="M12 2L3 7v10l9 5 9-5V7l-9-5zM12 4.09L18.45 8 12 11.91 5.55 8 12 4.09zM5 9.87l6 3.64v7.23L5 17.13V9.87zm8 10.87V13.5l6-3.64v7.27l-6 3.64z"
                  fill="currentColor"
                />
              </svg>
            </div>
            <span className="text-xl font-bold">
              <span className="text-[#4285F4]">Avyen</span>
              <span>Co</span>
            </span>
          </div>

          {!isMobile && (
            <nav className="hidden md:flex items-center gap-8">
              <button
                onClick={() => scrollToSection(heroRef)}
                className="text-gray-300 hover:text-[#4285F4] transition-colors"
              >
                Home
              </button>
              <button
                onClick={() => scrollToSection(servicesRef)}
                className="text-gray-300 hover:text-[#4285F4] transition-colors"
              >
                Services
              </button>
              <button
                onClick={() => scrollToSection(dashboardRef)}
                className="text-gray-300 hover:text-[#4285F4] transition-colors"
              >
                Solutions
              </button>
              <button
                onClick={() => scrollToSection(contactRef)}
                className="text-gray-300 hover:text-[#4285F4] transition-colors"
              >
                Contact
              </button>
            </nav>
          )}

          <Button className="bg-[#4285F4] hover:bg-[#3b77db] text-white">Get Started</Button>
        </div>
      </motion.header>

      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center">
        <div className="container mx-auto px-4 z-20 pt-20">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: heroInView ? 1 : 0, y: heroInView ? 0 : 50 }}
            transition={{ duration: 0.8 }}
            className="max-w-3xl mx-auto text-center"
          >
            <h1 className="text-3xl md:text-6xl font-bold mb-4 md:mb-6">
              <span className="text-[#4285F4]">Innovative</span> Software Solutions for Modern Businesses
            </h1>
            <p className="text-lg md:text-xl text-gray-300 mb-6 md:mb-8">
              We build custom software and dashboards that transform your data into actionable insights.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-[#4285F4] hover:bg-[#3b77db] text-white"
                onClick={() => scrollToSection(contactRef)}
              >
                Get in Touch
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-[#4285F4] text-[#4285F4] hover:bg-[#4285F4]/10"
                onClick={() => scrollToSection(servicesRef)}
              >
                Explore Services
              </Button>
            </div>
          </motion.div>
        </div>

        <motion.div
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2 cursor-pointer z-30"
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5 }}
          onClick={() => scrollToSection(servicesRef)}
        >
          <ArrowDown className="text-[#4285F4] h-8 w-8 md:h-10 md:w-10" />
        </motion.div>
      </section>

      {/* Services Section */}
      <section ref={servicesRef} className="relative min-h-screen flex items-center py-12 md:py-20">
        <div className="container mx-auto px-4 z-20">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: servicesInView ? 1 : 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-10 md:mb-16"
          >
            <h2 className="text-2xl md:text-5xl font-bold mb-3 md:mb-4">
              Our <span className="text-[#4285F4]">Services</span>
            </h2>
            <p className="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto">
              We deliver end-to-end software solutions tailored to your business needs
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8">
            {[
              {
                icon: <BarChart3 className="h-10 w-10 text-[#4285F4]" />,
                title: "Custom Dashboards",
                description: "Interactive data visualization dashboards that provide real-time insights",
              },
              {
                icon: <Code className="h-10 w-10 text-[#4285F4]" />,
                title: "Software Development",
                description: "Bespoke software solutions designed to solve your unique business challenges",
              },
              {
                icon: <Database className="h-10 w-10 text-[#4285F4]" />,
                title: "Data Integration",
                description: "Seamless integration of multiple data sources into unified platforms",
              },
              {
                icon: <Layers className="h-10 w-10 text-[#4285F4]" />,
                title: "Cloud Solutions",
                description: "Scalable cloud infrastructure and migration services",
              },
              {
                icon: <Settings className="h-10 w-10 text-[#4285F4]" />,
                title: "Process Automation",
                description: "Streamline operations with intelligent automation solutions",
              },
              {
                icon: <Users className="h-10 w-10 text-[#4285F4]" />,
                title: "Consulting",
                description: "Expert guidance on digital transformation and technology strategy",
              },
            ].map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: servicesInView ? 1 : 0, y: servicesInView ? 0 : 30 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-[#111827]/50 backdrop-blur-sm p-6 rounded-xl border border-gray-800 hover:border-[#4285F4]/50 transition-all hover:shadow-[0_0_15px_rgba(66,133,244,0.15)] group"
              >
                <div className="mb-4">{service.icon}</div>
                <h3 className="text-xl font-bold mb-2 group-hover:text-[#4285F4] transition-colors">{service.title}</h3>
                <p className="text-gray-400">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Dashboard Demo Section */}
      <section ref={dashboardRef} className="relative min-h-screen flex items-center py-12 md:py-20">
        <div className="container mx-auto px-4 z-20">
          <div className="flex flex-col lg:flex-row items-center gap-8 md:gap-12">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: dashboardInView ? 1 : 0, x: dashboardInView ? 0 : -50 }}
              transition={{ duration: 0.8 }}
              className="lg:w-1/2"
            >
              <h2 className="text-2xl md:text-5xl font-bold mb-4 md:mb-6">
                Transform Your Data into <span className="text-[#4285F4]">Actionable Insights</span>
              </h2>
              <p className="text-lg md:text-xl text-gray-300 mb-6 md:mb-8">
                Our custom dashboard solutions provide real-time visibility into your business metrics, helping you make
                data-driven decisions faster.
              </p>
              <ul className="space-y-3 md:space-y-4 mb-6 md:mb-8">
                {[
                  "Interactive data visualizations",
                  "Real-time data processing",
                  "Custom KPI tracking",
                  "Multi-device compatibility",
                  "Secure user access controls",
                ].map((feature, index) => (
                  <motion.li
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: dashboardInView ? 1 : 0, x: dashboardInView ? 0 : -20 }}
                    transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                    className="flex items-center gap-3"
                  >
                    <div className="h-2 w-2 rounded-full bg-[#4285F4]" />
                    <span>{feature}</span>
                  </motion.li>
                ))}
              </ul>
              <Button className="bg-[#4285F4] hover:bg-[#3b77db] text-white w-full sm:w-auto">
                See Our Dashboard Solutions
              </Button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: dashboardInView ? 1 : 0, x: dashboardInView ? 0 : 50 }}
              transition={{ duration: 0.8 }}
              className="w-full lg:w-1/2 mt-8 lg:mt-0"
            >
              <DashboardAnimation />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section ref={contactRef} className="relative min-h-screen flex items-center py-12 md:py-20">
        <div className="container mx-auto px-4 z-20">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: contactInView ? 1 : 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-10 md:mb-16"
          >
            <h2 className="text-2xl md:text-5xl font-bold mb-3 md:mb-4">
              Get in <span className="text-[#4285F4]">Touch</span>
            </h2>
            <p className="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto">
              Ready to transform your business with custom software solutions? Let's talk.
            </p>
          </motion.div>

          <div className="max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: contactInView ? 1 : 0, y: contactInView ? 0 : 30 }}
              transition={{ duration: 0.5 }}
              className="bg-[#111827]/50 backdrop-blur-sm p-5 md:p-8 rounded-xl border border-gray-800"
            >
              <form className="space-y-4 md:space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium">
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      className="w-full px-4 py-3 bg-black/50 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4285F4] focus:border-transparent"
                      placeholder="Your name"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      className="w-full px-4 py-3 bg-black/50 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4285F4] focus:border-transparent"
                      placeholder="your@email.com"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label htmlFor="subject" className="text-sm font-medium">
                    Subject
                  </label>
                  <input
                    type="text"
                    id="subject"
                    className="w-full px-4 py-3 bg-black/50 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4285F4] focus:border-transparent"
                    placeholder="How can we help?"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium">
                    Message
                  </label>
                  <textarea
                    id="message"
                    rows={5}
                    className="w-full px-4 py-3 bg-black/50 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4285F4] focus:border-transparent resize-none"
                    placeholder="Tell us about your project..."
                  />
                </div>
                <Button type="submit" className="w-full bg-[#4285F4] hover:bg-[#3b77db] text-white py-6">
                  Send Message
                </Button>
              </form>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative bg-black/50 backdrop-blur-sm py-8 md:py-12 border-t border-gray-800 z-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-6 md:mb-0">
              <div className="bg-[#4285F4] rounded-md p-1.5 flex items-center justify-center w-10 h-10">
                <svg
                  viewBox="0 0 24 24"
                  width="24"
                  height="24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="text-white"
                >
                  <path
                    d="M12 2L3 7v10l9 5 9-5V7l-9-5zM12 4.09L18.45 8 12 11.91 5.55 8 12 4.09zM5 9.87l6 3.64v7.23L5 17.13V9.87zm8 10.87V13.5l6-3.64v7.27l-6 3.64z"
                    fill="currentColor"
                  />
                </svg>
              </div>
              <span className="text-xl font-bold">
                <span className="text-[#4285F4]">Avyen</span>
                <span>Co</span>
              </span>
            </div>

            <div className="flex flex-wrap justify-center gap-6 md:gap-8 mb-6 md:mb-0">
              <button
                onClick={() => scrollToSection(servicesRef)}
                className="text-gray-400 hover:text-[#4285F4] transition-colors"
              >
                Services
              </button>
              <button
                onClick={() => scrollToSection(dashboardRef)}
                className="text-gray-400 hover:text-[#4285F4] transition-colors"
              >
                Solutions
              </button>
              <button
                onClick={() => scrollToSection(contactRef)}
                className="text-gray-400 hover:text-[#4285F4] transition-colors"
              >
                Contact
              </button>
            </div>
          </div>

          <div className="mt-6 md:mt-8 pt-6 md:pt-8 border-t border-gray-800 text-center text-gray-500 text-sm">
            <p>&copy; {new Date().getFullYear()} AvyenCo. All rights reserved.</p>
          </div>
        </div>
      </footer>
      {isMobile && (
        <div className="fixed bottom-0 left-0 right-0 bg-black/80 backdrop-blur-md border-t border-gray-800 z-50 py-3 px-4">
          <div className="flex justify-around items-center">
            <button
              onClick={() => scrollToSection(heroRef)}
              className="flex flex-col items-center text-xs text-gray-300 hover:text-[#4285F4] transition-colors"
            >
              <Home className="h-5 w-5 mb-1" />
              <span>Home</span>
            </button>
            <button
              onClick={() => scrollToSection(servicesRef)}
              className="flex flex-col items-center text-xs text-gray-300 hover:text-[#4285F4] transition-colors"
            >
              <Layers className="h-5 w-5 mb-1" />
              <span>Services</span>
            </button>
            <button
              onClick={() => scrollToSection(dashboardRef)}
              className="flex flex-col items-center text-xs text-gray-300 hover:text-[#4285F4] transition-colors"
            >
              <BarChart3 className="h-5 w-5 mb-1" />
              <span>Solutions</span>
            </button>
            <button
              onClick={() => scrollToSection(contactRef)}
              className="flex flex-col items-center text-xs text-gray-300 hover:text-[#4285F4] transition-colors"
            >
              <Users className="h-5 w-5 mb-1" />
              <span>Contact</span>
            </button>
          </div>
        </div>
      )}
    </main>
  )
}

