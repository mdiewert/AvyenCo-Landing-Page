"use client"

import { useState, useEffect } from "react"
import { motion, useScroll, useSpring } from "framer-motion"
import { useMobile } from "@/hooks/use-mobile"

export default function AnimatedBackground() {
  const isMobile = useMobile()
  const { scrollYProgress } = useScroll()
  const smoothScrollProgress = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001,
  })

  // State to store current interpolated positions
  const [currentPositions, setCurrentPositions] = useState<{
    shapes: Array<{ x: string; y: string; rotation: number }>
    particles: Array<{ x: string; y: string }>
  }>({
    shapes: [],
    particles: [],
  })

  // Generate initial random shapes
  const generateInitialShapes = (count: number) => {
    return Array.from({ length: count }, (_, i) => {
      const isOutline = Math.random() > 0.6 // 40% chance of outline
      const shapeType = Math.floor(Math.random() * 5) // 0: circle, 1: square, 2: hexagon, 3: triangle, 4: diamond
      const size = isMobile ? 15 + Math.random() * 80 : 20 + Math.random() * 120
      const posX = Math.random() * 100
      const posY = Math.random() * 100 // Position based on % of viewport height
      const opacity = 0.15 + Math.random() * 0.3
      const blur = Math.random() > 0.7 ? "blur-sm" : "blur-none"
      const rotation = Math.random() * 360 // Random rotation

      // Generate a second position for smooth transitions
      const posX2 = Math.max(0, Math.min(100, posX + (Math.random() * 20 - 10)))
      const posY2 = Math.max(0, Math.min(100, posY + (Math.random() * 20 - 10)))
      const rotation2 = rotation + (Math.random() * 40 - 20)

      // Generate a third position for more variation
      const posX3 = Math.max(0, Math.min(100, posX2 + (Math.random() * 20 - 10)))
      const posY3 = Math.max(0, Math.min(100, posY2 + (Math.random() * 20 - 10)))
      const rotation3 = rotation2 + (Math.random() * 40 - 20)

      // Generate a fourth position to complete the cycle
      const posX4 = Math.max(0, Math.min(100, posX3 + (Math.random() * 20 - 10)))
      const posY4 = Math.max(0, Math.min(100, posY3 + (Math.random() * 20 - 10)))
      const rotation4 = rotation3 + (Math.random() * 40 - 20)

      return {
        id: i,
        isOutline,
        shapeType,
        size,
        opacity,
        blur,
        // Store all positions for interpolation
        positions: [
          { x: posX, y: posY, rotation: rotation },
          { x: posX2, y: posY2, rotation: rotation2 },
          { x: posX3, y: posY3, rotation: rotation3 },
          { x: posX4, y: posY4, rotation: rotation4 },
        ],
      }
    })
  }

  // Reduced number of shapes on mobile
  const [shapes] = useState(() => generateInitialShapes(isMobile ? 10 : 18))

  // Generate particles with multiple positions
  const generateParticles = (count: number) => {
    return Array.from({ length: count }, (_, index) => {
      const size = 1 + Math.random() * 2
      const posX = Math.random() * 100
      const posY = Math.random() * 100
      const opacity = 0.3 + Math.random() * 0.5

      // Generate additional positions for smooth transitions
      const posX2 = Math.max(0, Math.min(100, posX + (Math.random() * 10 - 5)))
      const posY2 = Math.max(0, Math.min(100, posY + (Math.random() * 10 - 5)))

      const posX3 = Math.max(0, Math.min(100, posX2 + (Math.random() * 10 - 5)))
      const posY3 = Math.max(0, Math.min(100, posY2 + (Math.random() * 10 - 5)))

      const posX4 = Math.max(0, Math.min(100, posX3 + (Math.random() * 10 - 5)))
      const posY4 = Math.max(0, Math.min(100, posY3 + (Math.random() * 10 - 5)))

      return {
        id: index,
        size,
        opacity,
        positions: [
          { x: posX, y: posY },
          { x: posX2, y: posY2 },
          { x: posX3, y: posY3 },
          { x: posX4, y: posY4 },
        ],
      }
    })
  }

  const [particles] = useState(() => generateParticles(isMobile ? 12 : 20))

  // Update positions based on scroll progress
  useEffect(() => {
    const updatePositions = () => {
      const progress = smoothScrollProgress.get()

      // Calculate interpolated positions for shapes
      const newShapePositions = shapes.map((shape) => {
        const { positions } = shape

        // Determine which segment we're in
        let segment = 0
        let segmentProgress = 0

        if (progress <= 0.33) {
          segment = 0
          segmentProgress = progress / 0.33
        } else if (progress <= 0.66) {
          segment = 1
          segmentProgress = (progress - 0.33) / 0.33
        } else {
          segment = 2
          segmentProgress = (progress - 0.66) / 0.34
        }

        // Interpolate between positions
        const pos1 = positions[segment]
        const pos2 = positions[segment + 1]

        const x = pos1.x + (pos2.x - pos1.x) * segmentProgress
        const y = pos1.y + (pos2.y - pos1.y) * segmentProgress
        const rotation = pos1.rotation + (pos2.rotation - pos1.rotation) * segmentProgress

        return {
          x: `${x}%`,
          y: `${y}%`,
          rotation,
        }
      })

      // Calculate interpolated positions for particles
      const newParticlePositions = particles.map((particle) => {
        const { positions } = particle

        // Determine which segment we're in
        let segment = 0
        let segmentProgress = 0

        if (progress <= 0.33) {
          segment = 0
          segmentProgress = progress / 0.33
        } else if (progress <= 0.66) {
          segment = 1
          segmentProgress = (progress - 0.33) / 0.33
        } else {
          segment = 2
          segmentProgress = (progress - 0.66) / 0.34
        }

        // Interpolate between positions
        const pos1 = positions[segment]
        const pos2 = positions[segment + 1]

        const x = pos1.x + (pos2.x - pos1.x) * segmentProgress
        const y = pos1.y + (pos2.y - pos1.y) * segmentProgress

        return {
          x: `${x}%`,
          y: `${y}%`,
        }
      })

      setCurrentPositions({
        shapes: newShapePositions,
        particles: newParticlePositions,
      })
    }

    // Set initial positions
    updatePositions()

    // Subscribe to scroll progress changes
    const unsubscribe = smoothScrollProgress.onChange(updatePositions)

    return () => {
      unsubscribe()
    }
  }, [shapes, particles, smoothScrollProgress])

  return (
    <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
      <div className="absolute inset-0 bg-[#0f1116]">
        <div className="absolute inset-0 opacity-30 bg-grid-pattern" />

        {shapes.map((shape, index) => {
          // Get current interpolated position
          const position = currentPositions.shapes[index] || {
            x: `${shape.positions[0].x}%`,
            y: `${shape.positions[0].y}%`,
            rotation: shape.positions[0].rotation,
          }

          // Shape-specific styles
          let shapeElement

          if (shape.isOutline) {
            // Outlined shapes
            switch (shape.shapeType) {
              case 0: // Circle
                shapeElement = (
                  <div
                    className={`absolute rounded-full border-2 border-[#4285F4] ${shape.blur}`}
                    style={{
                      width: shape.size,
                      height: shape.size,
                      left: position.x,
                      top: position.y,
                      transform: `rotate(${position.rotation}deg)`,
                      opacity: shape.opacity * 1.5, // Higher opacity for outlines
                    }}
                  />
                )
                break
              case 1: // Square
                shapeElement = (
                  <div
                    className={`absolute border-2 border-[#4285F4] ${shape.blur}`}
                    style={{
                      width: shape.size,
                      height: shape.size,
                      left: position.x,
                      top: position.y,
                      transform: `rotate(${position.rotation}deg)`,
                      opacity: shape.opacity * 1.5,
                    }}
                  />
                )
                break
              case 2: // Hexagon - using clip-path
                shapeElement = (
                  <div
                    className={`absolute border-2 border-[#4285F4] ${shape.blur}`}
                    style={{
                      width: shape.size,
                      height: shape.size,
                      left: position.x,
                      top: position.y,
                      transform: `rotate(${position.rotation}deg)`,
                      clipPath: "polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)",
                      opacity: shape.opacity * 1.5,
                    }}
                  />
                )
                break
              case 3: // Triangle - using clip-path
                shapeElement = (
                  <div
                    className={`absolute border-2 border-[#4285F4] ${shape.blur}`}
                    style={{
                      width: shape.size,
                      height: shape.size,
                      left: position.x,
                      top: position.y,
                      transform: `rotate(${position.rotation}deg)`,
                      clipPath: "polygon(50% 0%, 0% 100%, 100% 100%)",
                      opacity: shape.opacity * 1.5,
                    }}
                  />
                )
                break
              case 4: // Diamond - using clip-path
                shapeElement = (
                  <div
                    className={`absolute border-2 border-[#4285F4] ${shape.blur}`}
                    style={{
                      width: shape.size,
                      height: shape.size,
                      left: position.x,
                      top: position.y,
                      transform: `rotate(${position.rotation}deg)`,
                      clipPath: "polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)",
                      opacity: shape.opacity * 1.5,
                    }}
                  />
                )
                break
              default:
                shapeElement = null
            }
          } else {
            // Filled shapes
            switch (shape.shapeType) {
              case 0: // Circle
                shapeElement = (
                  <div
                    className={`absolute rounded-full bg-[#4285F4] ${shape.blur}`}
                    style={{
                      width: shape.size,
                      height: shape.size,
                      left: position.x,
                      top: position.y,
                      transform: `rotate(${position.rotation}deg)`,
                      opacity: shape.opacity,
                    }}
                  />
                )
                break
              case 1: // Square
                shapeElement = (
                  <div
                    className={`absolute bg-[#4285F4] ${shape.blur}`}
                    style={{
                      width: shape.size,
                      height: shape.size,
                      left: position.x,
                      top: position.y,
                      transform: `rotate(${position.rotation}deg)`,
                      opacity: shape.opacity * 1.2, // Slightly higher opacity for squares
                    }}
                  />
                )
                break
              case 2: // Hexagon - using clip-path
                shapeElement = (
                  <div
                    className={`absolute bg-[#4285F4] ${shape.blur}`}
                    style={{
                      width: shape.size,
                      height: shape.size,
                      left: position.x,
                      top: position.y,
                      transform: `rotate(${position.rotation}deg)`,
                      clipPath: "polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)",
                      opacity: shape.opacity,
                    }}
                  />
                )
                break
              case 3: // Triangle - using clip-path
                shapeElement = (
                  <div
                    className={`absolute bg-[#4285F4] ${shape.blur}`}
                    style={{
                      width: shape.size,
                      height: shape.size,
                      left: position.x,
                      top: position.y,
                      transform: `rotate(${position.rotation}deg)`,
                      clipPath: "polygon(50% 0%, 0% 100%, 100% 100%)",
                      opacity: shape.opacity,
                    }}
                  />
                )
                break
              case 4: // Diamond - using clip-path
                shapeElement = (
                  <div
                    className={`absolute bg-[#4285F4] ${shape.blur}`}
                    style={{
                      width: shape.size,
                      height: shape.size,
                      left: position.x,
                      top: position.y,
                      transform: `rotate(${position.rotation}deg)`,
                      clipPath: "polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)",
                      opacity: shape.opacity,
                    }}
                  />
                )
                break
              default:
                shapeElement = null
            }
          }

          return (
            <motion.div
              key={shape.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: shape.id * 0.1 }}
            >
              {shapeElement}
            </motion.div>
          )
        })}

        {/* Floating particles with smooth transitions */}
        {particles.map((particle, index) => {
          // Get current interpolated position
          const position = currentPositions.particles[index] || {
            x: `${particle.positions[0].x}%`,
            y: `${particle.positions[0].y}%`,
          }

          return (
            <motion.div
              key={`particle-${particle.id}`}
              className="absolute rounded-full bg-[#4285F4]/80"
              style={{
                width: particle.size,
                height: particle.size,
                left: position.x,
                top: position.y,
                opacity: particle.opacity,
              }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: particle.id * 0.05 }}
            />
          )
        })}
      </div>
    </div>
  )
}

