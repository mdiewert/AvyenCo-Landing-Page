"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"

export default function DashboardAnimation() {
  const containerRef = useRef<HTMLDivElement>(null)
  const isInView = useInView(containerRef, { once: false, amount: 0.3 })

  // Bar chart data
  const barData = [
    { label: "Efficiency", value: 75 },
    { label: "Time Management", value: 90 },
  ]

  return (
    <div
      ref={containerRef}
      className="relative w-full aspect-[4/3] rounded-xl overflow-hidden border border-gray-800 shadow-xl bg-gradient-to-br from-[#0f172a] to-black p-4 md:p-8"
    >
      <div className="absolute inset-0 bg-[#4285F4]/5 pointer-events-none" />

      <motion.h2
        initial={{ opacity: 0 }}
        animate={{ opacity: isInView ? 1 : 0 }}
        transition={{ duration: 0.6 }}
        className="text-xl md:text-3xl font-bold text-white text-center mb-6 md:mb-12"
      >
        <span className="text-[#4285F4]">Productivity</span> Metrics
      </motion.h2>

      <div className="flex justify-around items-end h-[60%] px-2 md:px-4">
        {/* First two bars that grow upward */}
        {barData.map((bar, index) => (
          <div key={index} className="flex flex-col items-center">
            <div className="h-48 md:h-64 flex items-end">
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{
                  height: isInView ? `${bar.value}%` : 0,
                  opacity: isInView ? 1 : 0,
                }}
                transition={{
                  duration: 3.5,
                  delay: index * 0.4,
                  ease: "easeOut",
                }}
                className="w-8 sm:w-12 md:w-16 rounded-lg bg-[#4285F4]"
                style={{
                  minHeight: isInView ? "60px" : "0px",
                  maxHeight: "250px",
                }}
              />
            </div>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: isInView ? 1 : 0 }}
              transition={{ duration: 0.5, delay: 0.3 + index * 0.2 }}
              className="mt-2 md:mt-4 text-sm md:text-base text-white font-medium text-center"
            >
              {bar.label}
            </motion.p>
          </div>
        ))}

        {/* Stress bar that decreases from full height */}
        <div className="flex flex-col items-center">
          <div className="h-48 md:h-64 flex items-end">
            <motion.div
              initial={{ height: "100%", opacity: 0 }}
              animate={{
                height: isInView ? "40%" : "100%",
                opacity: isInView ? 1 : 0,
              }}
              transition={{
                duration: 3.5,
                delay: 0.8,
                ease: "easeOut",
              }}
              className="w-8 sm:w-12 md:w-16 rounded-lg bg-[#4285F4]"
              style={{
                minHeight: isInView ? "40px" : "0px",
              }}
            />
          </div>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: isInView ? 1 : 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
            className="mt-2 md:mt-4 text-sm md:text-base text-white font-medium text-center"
          >
            Stress
          </motion.p>
        </div>
      </div>
    </div>
  )
}

